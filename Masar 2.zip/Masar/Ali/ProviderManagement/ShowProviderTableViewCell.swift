//
//  ShowProviderTableViewCell.swift
//  Masar
//
//  Created by BP-36-201-10 on 21/12/2025.
//

import UIKit

class ShowProviderTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
