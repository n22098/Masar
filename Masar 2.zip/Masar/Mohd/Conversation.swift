//
//  Conversation.swift
//  Masar
//
//
//  Conversation.swift
//  Masar
//

import Foundation

struct Conversation {
    let id: String
    let user: AppUser
    let lastMessage: String
    let lastUpdated: Date
    
    
}
