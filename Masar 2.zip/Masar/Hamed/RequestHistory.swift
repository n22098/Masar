//
//  RequestHistory.swift
//  Masar
//
//  Created by BP-36-201-08 on 20/12/2025.
//

import UIKit

class RequestHistory: UIViewController {

    @IBOutlet weak var nameTextField: UILabel!
    @IBOutlet weak var serviceTextField: UILabel!
    @IBOutlet weak var dateTextField: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    @IBAction func ratingBtn(_ sender: UIButton) {
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
