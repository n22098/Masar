import UIKit
import FirebaseFirestore
import FirebaseAuth

class BookingHistoryTableViewController: UITableViewController {
    
    // MARK: - Properties
    private lazy var filterSegment: UISegmentedControl = {
        let items = ["Upcoming", "Completed", "Canceled"]
        let segment = UISegmentedControl(items: items)
        let brandColor = UIColor(red: 98/255, green: 84/255, blue: 243/255, alpha: 1.0)
        segment.selectedSegmentIndex = 0
        segment.translatesAutoresizingMaskIntoConstraints = false
        segment.backgroundColor = UIColor(white: 0.95, alpha: 1)
        segment.selectedSegmentTintColor = .white
        segment.setTitleTextAttributes([.foregroundColor: UIColor.gray], for: .normal)
        segment.setTitleTextAttributes([.foregroundColor: brandColor, .font: UIFont.systemFont(ofSize: 14, weight: .semibold)], for: .selected)
        return segment
    }()
    
    var allBookings: [BookingModel] = []
    var filteredBookings: [BookingModel] = []
    let brandColor = UIColor(red: 98/255, green: 84/255, blue: 243/255, alpha: 1.0)
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "History"
        setupNavigationBar()
        setupUI()
        
        tableView.register(ModernBookingHistoryCell.self, forCellReuseIdentifier: "ModernBookingHistoryCell")
        
        updateBackgroundView()
        loadUserDataThenFetchBookings()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadUserDataThenFetchBookings()
    }
    
    // MARK: - CRITICAL FIX: Load User Data First
    private func loadUserDataThenFetchBookings() {
        print("🔄 [History] Loading user data first...")
        
        guard let currentUser = Auth.auth().currentUser else {
            print("❌ [History] No Firebase Auth user - cannot proceed")
            showEmptyState()
            return
        }
        
        print("✅ [History] Firebase Auth user found: \(currentUser.uid)")
        print("📧 [History] Email: \(currentUser.email ?? "no email")")
        
        // CRITICAL: Load user data from Firestore if UserManager is empty
        if UserManager.shared.currentUser == nil {
            print("⚠️ [History] UserManager is nil, loading from Firestore...")
            
            let db = Firestore.firestore()
            db.collection("users").document(currentUser.uid).getDocument { [weak self] snapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    print("❌ [History] Error loading user data: \(error)")
                    self.showEmptyState()
                    return
                }
                
                guard let data = snapshot?.data() else {
                    print("❌ [History] No user data found in Firestore")
                    self.showEmptyState()
                    return
                }
                
                // Load user data into UserManager
                let role = data["role"] as? String ?? "seeker"
                let name = data["name"] as? String ?? data["username"] as? String ?? "User"
                let email = data["email"] as? String ?? currentUser.email ?? ""
                
                print("✅ [History] Loaded user data from Firestore:")
                print("   - Name: \(name)")
                print("   - Email: \(email)")
                print("   - Role: \(role)")
                
                // NOW fetch bookings with the correct logic
                self.fetchBookingsBasedOnRole(uid: currentUser.uid, email: email, role: role)
            }
        } else {
            // UserManager has data, use it
            let role = UserManager.shared.currentUser?.role ?? "seeker"
            let email = UserManager.shared.currentUser?.email ?? currentUser.email ?? ""
            
            print("✅ [History] Using UserManager data:")
            print("   - Role: \(role)")
            print("   - Email: \(email)")
            
            fetchBookingsBasedOnRole(uid: currentUser.uid, email: email, role: role)
        }
    }
    
    // MARK: - CRITICAL FIX: Fetch Based on Role
    private func fetchBookingsBasedOnRole(uid: String, email: String, role: String) {
        print("🔍 [History] Fetching bookings...")
        print("   - UID: \(uid)")
        print("   - Email: \(email)")
        print("   - Role: \(role)")
        
        let db = Firestore.firestore()
        
        // CRITICAL: Different query based on role
        let query: Query
        
        if role.lowercased() == "provider" {
            // Provider: Get bookings WHERE providerId == my UID
            print("👨‍💼 [History] Fetching as PROVIDER (bookings sent TO me)")
            query = db.collection("bookings")
                .whereField("providerId", isEqualTo: uid)
        } else {
            // Seeker: Get bookings WHERE email == my email
            print("👤 [History] Fetching as SEEKER (bookings I MADE)")
            query = db.collection("bookings")
                .whereField("email", isEqualTo: email)
        }
        
        query.getDocuments { [weak self] snapshot, error in
            guard let self = self else { return }
            
            if let error = error {
                print("❌ [History] Error fetching bookings: \(error)")
                self.showEmptyState()
                return
            }
            
            guard let documents = snapshot?.documents else {
                print("⚠️ [History] No documents found")
                self.showEmptyState()
                return
            }
            
            print("📦 [History] Found \(documents.count) documents")
            
            var bookings: [BookingModel] = []
            
            for doc in documents {
                // FIXED: Manual parsing instead of Codable
                let data = doc.data()
                
                guard let serviceName = data["serviceName"] as? String,
                      let seekerName = data["seekerName"] as? String,
                      let providerName = data["providerName"] as? String,
                      let email = data["email"] as? String,
                      let phoneNumber = data["phoneNumber"] as? String,
                      let price = data["price"] as? Double,
                      let descriptionText = data["descriptionText"] as? String,
                      let statusString = data["status"] as? String,
                      let timestamp = data["date"] as? Timestamp else {
                    print("  ⚠️ Skipping document \(doc.documentID) - missing required fields")
                    continue
                }
                
                // Parse status
                let status: BookingStatus
                switch statusString {
                case "Upcoming":
                    status = .upcoming
                case "Completed":
                    status = .completed
                case "Canceled":
                    status = .canceled
                default:
                    status = .upcoming
                }
                
                let booking = BookingModel(
                    id: doc.documentID,
                    seekerName: seekerName,
                    serviceName: serviceName,
                    date: timestamp.dateValue(),
                    status: status,
                    providerName: providerName,
                    providerId: data["providerId"] as? String,
                    email: email,
                    phoneNumber: phoneNumber,
                    price: price,
                    instructions: data["instructions"] as? String,
                    descriptionText: descriptionText
                )
                
                print("  ✅ Loaded booking: \(booking.serviceName)")
                print("     - Status: \(booking.status.rawValue)")
                print("     - Email: \(booking.email)")
                print("     - Provider: \(booking.providerName)")
                
                bookings.append(booking)
            }
            
            DispatchQueue.main.async {
                self.allBookings = bookings
                print("💾 [History] Set allBookings count: \(self.allBookings.count)")
                
                self.filterBookings()
                print("🔍 [History] After filtering, filteredBookings count: \(self.filteredBookings.count)")
                
                self.tableView.reloadData()
                self.updateBackgroundView()
                
                print("✅ [History] UI updated successfully")
            }
        }
    }
    
    private func showEmptyState() {
        DispatchQueue.main.async {
            self.allBookings = []
            self.filterBookings()
            self.tableView.reloadData()
            self.updateBackgroundView()
        }
    }
    
    // MARK: - UI Setup
    func setupNavigationBar() {
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = brandColor
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 34, weight: .bold)]
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        navigationController?.navigationBar.tintColor = .white
    }
    
    func setupUI() {
        tableView.backgroundColor = UIColor(red: 248/255, green: 248/255, blue: 252/255, alpha: 1.0)
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 20, right: 0)
        setupSegmentHeader()
    }
    
    func setupSegmentHeader() {
        let headerContainer = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 60))
        headerContainer.backgroundColor = UIColor(red: 248/255, green: 248/255, blue: 252/255, alpha: 1.0)
        headerContainer.addSubview(filterSegment)
        NSLayoutConstraint.activate([
            filterSegment.leadingAnchor.constraint(equalTo: headerContainer.leadingAnchor, constant: 16),
            filterSegment.trailingAnchor.constraint(equalTo: headerContainer.trailingAnchor, constant: -16),
            filterSegment.centerYAnchor.constraint(equalTo: headerContainer.centerYAnchor),
            filterSegment.heightAnchor.constraint(equalToConstant: 40)
        ])
        filterSegment.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        tableView.tableHeaderView = headerContainer
    }
    
    @objc func segmentChanged() {
        filterBookings()
        tableView.reloadData()
        updateBackgroundView()
    }
    
    func filterBookings() {
        let previousCount = filteredBookings.count
        
        switch filterSegment.selectedSegmentIndex {
        case 0:
            filteredBookings = allBookings.filter { $0.status == .upcoming }
            print("🔍 [Filter] Upcoming: \(filteredBookings.count) bookings")
        case 1:
            filteredBookings = allBookings.filter { $0.status == .completed }
            print("🔍 [Filter] Completed: \(filteredBookings.count) bookings")
        case 2:
            filteredBookings = allBookings.filter { $0.status == .canceled }
            print("🔍 [Filter] Canceled: \(filteredBookings.count) bookings")
        default:
            filteredBookings = allBookings
            print("🔍 [Filter] All: \(filteredBookings.count) bookings")
        }
        
        print("📊 [Filter] Changed from \(previousCount) to \(filteredBookings.count)")
    }
    
    func updateBackgroundView() {
        if filteredBookings.isEmpty {
            let emptyView = UIView(frame: tableView.bounds)
            
            let stackView = UIStackView()
            stackView.axis = .vertical
            stackView.alignment = .center
            stackView.spacing = 16
            stackView.translatesAutoresizingMaskIntoConstraints = false
            
            let imageView = UIImageView()
            let config = UIImage.SymbolConfiguration(pointSize: 70, weight: .regular)
            imageView.image = UIImage(systemName: "calendar.badge.clock", withConfiguration: config)
            imageView.tintColor = brandColor
            imageView.contentMode = .scaleAspectFit
            
            let titleLabel = UILabel()
            titleLabel.text = "No request history"
            titleLabel.font = UIFont.systemFont(ofSize: 22, weight: .bold)
            titleLabel.textColor = .black
            titleLabel.textAlignment = .center
            
            let messageLabel = UILabel()
            messageLabel.text = "No history of requests made on Masar"
            messageLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
            messageLabel.textColor = .gray
            messageLabel.textAlignment = .center
            messageLabel.numberOfLines = 0
            
            stackView.addArrangedSubview(imageView)
            stackView.addArrangedSubview(titleLabel)
            stackView.addArrangedSubview(messageLabel)
            
            emptyView.addSubview(stackView)
            
            NSLayoutConstraint.activate([
                stackView.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor),
                stackView.centerYAnchor.constraint(equalTo: emptyView.centerYAnchor, constant: -50),
                stackView.leadingAnchor.constraint(equalTo: emptyView.leadingAnchor, constant: 40),
                stackView.trailingAnchor.constraint(equalTo: emptyView.trailingAnchor, constant: -40)
            ])
            
            tableView.backgroundView = emptyView
        } else {
            tableView.backgroundView = nil
        }
    }
    
    // MARK: - TableView Data Source
    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredBookings.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ModernBookingHistoryCell", for: indexPath) as! ModernBookingHistoryCell
        let booking = filteredBookings[indexPath.row]
        cell.configure(with: booking)
        
        cell.onRateTapped = { [weak self] in
            self?.showRatingScreen(for: booking)
        }
        
        return cell
    }
    
    private func showRatingScreen(for booking: BookingModel) {
        guard let providerId = booking.providerId, !providerId.isEmpty else {
            let alert = UIAlertController(
                title: "Cannot Rate",
                message: "This booking doesn't have provider information.",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
            return
        }
        
        guard let ratingVC = storyboard?.instantiateViewController(withIdentifier: "RatingViewController") as? RatingViewController else {
            print("❌ Failed to load RatingViewController from storyboard")
            return
        }
        
        ratingVC.bookingName = booking.serviceName
        ratingVC.providerId = providerId
        ratingVC.providerName = booking.providerName
        
        navigationController?.pushViewController(ratingVC, animated: true)
    }
    
    // MARK: - CRITICAL FIX: Cancel Instead of Delete
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let booking = filteredBookings[indexPath.row]
        
        // Only show cancel for Upcoming bookings
        if booking.status == .upcoming {
            let cancelAction = UIContextualAction(style: .destructive, title: "Cancel") { [weak self] (action, view, completionHandler) in
                self?.confirmCancellation(at: indexPath)
                completionHandler(true)
            }
            
            cancelAction.backgroundColor = .systemOrange
            cancelAction.image = UIImage(systemName: "xmark.circle.fill")
            
            return UISwipeActionsConfiguration(actions: [cancelAction])
        } else {
            // For completed/canceled, allow delete from history
            let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [weak self] (action, view, completionHandler) in
                self?.confirmDeletion(at: indexPath)
                completionHandler(true)
            }
            
            deleteAction.backgroundColor = .systemRed
            deleteAction.image = UIImage(systemName: "trash.fill")
            
            return UISwipeActionsConfiguration(actions: [deleteAction])
        }
    }
    
    func confirmCancellation(at indexPath: IndexPath) {
        let alert = UIAlertController(
            title: "Cancel Booking",
            message: "Are you sure you want to cancel this booking?",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "No", style: .cancel))
        alert.addAction(UIAlertAction(title: "Yes, Cancel", style: .destructive, handler: { [weak self] _ in
            self?.cancelBooking(at: indexPath)
        }))
        
        present(alert, animated: true)
    }
    
    func cancelBooking(at indexPath: IndexPath) {
        guard indexPath.row < filteredBookings.count else { return }
        
        let booking = filteredBookings[indexPath.row]
        guard let bookingId = booking.id else { return }
        
        // Update status to Canceled in Firebase
        let db = Firestore.firestore()
        db.collection("bookings").document(bookingId).updateData([
            "status": "Canceled"
        ]) { [weak self] error in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Error canceling booking: \(error)")
                    let errorAlert = UIAlertController(
                        title: "Error",
                        message: "Failed to cancel booking. Please try again.",
                        preferredStyle: .alert
                    )
                    errorAlert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(errorAlert, animated: true)
                } else {
                    print("✅ Booking canceled successfully")
                    
                    // Update local data
                    if let allIndex = self.allBookings.firstIndex(where: { $0.id == bookingId }) {
                        self.allBookings[allIndex].status = .canceled
                    }
                    
                    // Remove from filtered list (it's in Upcoming, moving to Canceled)
                    self.filteredBookings.remove(at: indexPath.row)
                    self.tableView.deleteRows(at: [indexPath], with: .fade)
                    self.updateBackgroundView()
                    
                    // Show success message
                    let successAlert = UIAlertController(
                        title: "Booking Canceled",
                        message: "Your booking has been canceled.",
                        preferredStyle: .alert
                    )
                    successAlert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(successAlert, animated: true)
                }
            }
        }
    }
    
    func confirmDeletion(at indexPath: IndexPath) {
        let alert = UIAlertController(
            title: "Delete Booking",
            message: "Are you sure you want to delete this booking from history?",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { [weak self] _ in
            self?.deleteBooking(at: indexPath)
        }))
        
        present(alert, animated: true)
    }
    
    func deleteBooking(at indexPath: IndexPath) {
        guard indexPath.row < filteredBookings.count else { return }
        
        let booking = filteredBookings[indexPath.row]
        guard let bookingId = booking.id else { return }
        
        filteredBookings.remove(at: indexPath.row)
        
        if let index = allBookings.firstIndex(where: { $0.id == bookingId }) {
            allBookings.remove(at: index)
        }
        
        tableView.deleteRows(at: [indexPath], with: .left)
        updateBackgroundView()
        
        Firestore.firestore().collection("bookings").document(bookingId).delete { error in
            if let error = error {
                print("❌ Error deleting from Firestore: \(error)")
            } else {
                print("✅ Deleted from Firestore successfully")
            }
        }
    }
    
    // MARK: - Navigation
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if indexPath.row < filteredBookings.count {
            let selectedBooking = filteredBookings[indexPath.row]
            performSegue(withIdentifier: "showBookingDetails", sender: selectedBooking)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destVC = segue.destination as? Bookinghistoryapp,
           let booking = sender as? BookingModel {
            destVC.bookingData = booking
            destVC.onStatusChanged = { [weak self] newStatus in
                guard let self = self else { return }
                if let index = self.allBookings.firstIndex(where: { $0.id == booking.id }) {
                    self.allBookings[index].status = newStatus
                }
                self.filterBookings()
                self.tableView.reloadData()
            }
        }
    }
}

// MARK: - ModernBookingHistoryCell
class ModernBookingHistoryCell: UITableViewCell {
    
    var onRateTapped: (() -> Void)?
    
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.08
        view.layer.shadowOffset = CGSize(width: 0, height: 4)
        view.layer.shadowRadius = 8
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let serviceNameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        label.textColor = .black
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let providerNameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        label.textColor = .darkGray
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let dateLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        label.textColor = .gray
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let priceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 17, weight: .heavy)
        label.textColor = UIColor(red: 98/255, green: 84/255, blue: 243/255, alpha: 1.0)
        label.textAlignment = .right
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        label.textAlignment = .center
        label.layer.cornerRadius = 8
        label.layer.masksToBounds = true
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var rateButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Rate", for: .normal)
        btn.setTitleColor(UIColor.systemBlue, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        btn.layer.borderWidth = 1
        btn.layer.borderColor = UIColor.systemBlue.cgColor
        btn.layer.cornerRadius = 12
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.addTarget(self, action: #selector(rateButtonTapped), for: .touchUpInside)
        return btn
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    private func setupUI() {
        backgroundColor = .clear
        selectionStyle = .none
        
        contentView.addSubview(containerView)
        containerView.addSubview(serviceNameLabel)
        containerView.addSubview(providerNameLabel)
        containerView.addSubview(dateLabel)
        containerView.addSubview(priceLabel)
        containerView.addSubview(statusLabel)
        containerView.addSubview(rateButton)
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            
            serviceNameLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 16),
            serviceNameLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            serviceNameLabel.trailingAnchor.constraint(lessThanOrEqualTo: statusLabel.leadingAnchor, constant: -8),
            
            providerNameLabel.topAnchor.constraint(equalTo: serviceNameLabel.bottomAnchor, constant: 4),
            providerNameLabel.leadingAnchor.constraint(equalTo: serviceNameLabel.leadingAnchor),
            
            dateLabel.topAnchor.constraint(equalTo: providerNameLabel.bottomAnchor, constant: 8),
            dateLabel.leadingAnchor.constraint(equalTo: serviceNameLabel.leadingAnchor),
            dateLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -16),
            
            statusLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 16),
            statusLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            statusLabel.heightAnchor.constraint(equalToConstant: 24),
            statusLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 80),
            
            rateButton.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 8),
            rateButton.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            rateButton.widthAnchor.constraint(equalToConstant: 70),
            rateButton.heightAnchor.constraint(equalToConstant: 30),
            
            priceLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -16),
            priceLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
        ])
    }
    
    @objc private func rateButtonTapped() {
        onRateTapped?()
    }
    
    func configure(with booking: BookingModel) {
        serviceNameLabel.text = booking.serviceName
        providerNameLabel.text = booking.providerName
        dateLabel.text = "📅 \(booking.dateString)"
        priceLabel.text = booking.priceString
        statusLabel.text = "  \(booking.status.rawValue)  "
        
        switch booking.status {
        case .upcoming:
            statusLabel.textColor = UIColor(red: 255/255, green: 149/255, blue: 0/255, alpha: 1)
            statusLabel.backgroundColor = UIColor(red: 255/255, green: 149/255, blue: 0/255, alpha: 0.1)
            rateButton.isHidden = true
        case .completed:
            statusLabel.textColor = UIColor(red: 52/255, green: 199/255, blue: 89/255, alpha: 1)
            statusLabel.backgroundColor = UIColor(red: 52/255, green: 199/255, blue: 89/255, alpha: 0.1)
            rateButton.isHidden = false
        case .canceled, .rejected:
            statusLabel.textColor = UIColor(red: 255/255, green: 59/255, blue: 48/255, alpha: 1)
            statusLabel.backgroundColor = UIColor(red: 255/255, green: 59/255, blue: 48/255, alpha: 0.1)
            rateButton.isHidden = true
        }
    }
}
