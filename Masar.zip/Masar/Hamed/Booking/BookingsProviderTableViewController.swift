import UIKit
import FirebaseAuth
import FirebaseFirestore

class BookingsProviderTableViewController: UITableViewController {
    
    // MARK: - Properties
    let brandColor = UIColor(red: 0.35, green: 0.34, blue: 0.91, alpha: 1.0)
    
    var allBookings: [BookingModel] = []
    var filteredBookings: [BookingModel] = []
    var listener: ListenerRegistration?
    
    let segmentedControl: UISegmentedControl = {
        let items = ["Upcoming", "Completed", "Canceled"]
        let sc = UISegmentedControl(items: items)
        sc.selectedSegmentIndex = 0
        sc.translatesAutoresizingMaskIntoConstraints = false
        return sc
    }()
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        fetchDataFromFirebase()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupNavigationBar()
        updateListForCurrentSegment()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        listener?.remove()
    }
    
    // MARK: - Firebase Fetching
    private func fetchDataFromFirebase() {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        self.title = "Loading..."
        
        // البروفايدر يرى الحجوزات القادمة إليه (providerId == currentUid)
        let query = Firestore.firestore().collection("bookings")
            .whereField("providerId", isEqualTo: currentUid)
            
        self.listener = query.addSnapshotListener { [weak self] snapshot, error in
            guard let self = self else { return }
            
            guard let documents = snapshot?.documents else {
                self.allBookings = []
                self.updateListForCurrentSegment()
                return
            }
            
            self.allBookings = documents.compactMap { doc -> BookingModel? in
                let data = doc.data()
                
                return BookingModel(
                    id: doc.documentID,
                    serviceName: data["serviceName"] as? String ?? "Service",
                    providerName: data["providerName"] as? String ?? "Provider",
                    seekerName: data["seekerName"] as? String ?? "Client",
                    date: (data["date"] as? Timestamp)?.dateValue() ?? Date(),
                    status: BookingStatus(rawValue: data["status"] as? String ?? "Upcoming") ?? .upcoming,
                    totalPrice: data["totalPrice"] as? Double ?? 0.0,
                    notes: data["notes"] as? String ?? "",
                    email: data["email"] as? String ?? "",
                    phoneNumber: data["phoneNumber"] as? String ?? "",
                    providerId: data["providerId"] as? String ?? "",
                    seekerId: data["seekerId"] as? String ?? "",
                    serviceId: data["serviceId"] as? String ?? "",
                    descriptionText: data["descriptionText"] as? String ?? ""
                )
            }
            
            DispatchQueue.main.async {
                self.title = "Bookings"
                self.updateListForCurrentSegment()
            }
        }
    }
    
    // MARK: - UI Logic
    private func setupUI() {
        title = "Bookings"
        setupNavigationBar()
        setupTableView()
        setupHeaderView()
        setupSegmentedControlStyle()
    }
    
    private func setupNavigationBar() {
        navigationController?.navigationBar.prefersLargeTitles = true
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = brandColor
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 34, weight: .bold)]
        appearance.shadowColor = .clear
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        navigationController?.navigationBar.tintColor = .white
    }
    
    private func setupTableView() {
        tableView.backgroundColor = UIColor(red: 248/255, green: 248/255, blue: 252/255, alpha: 1.0)
        tableView.separatorStyle = .none
        tableView.rowHeight = 110
        tableView.register(BookingProviderCell.self, forCellReuseIdentifier: "BookingProviderCell")
    }
    
    private func setupHeaderView() {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 70))
        headerView.backgroundColor = UIColor(red: 248/255, green: 248/255, blue: 252/255, alpha: 1.0)
        headerView.addSubview(segmentedControl)
        NSLayoutConstraint.activate([
            segmentedControl.topAnchor.constraint(equalTo: headerView.topAnchor, constant: 12),
            segmentedControl.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            segmentedControl.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -16),
            segmentedControl.heightAnchor.constraint(equalToConstant: 40)
        ])
        segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        tableView.tableHeaderView = headerView
    }
    
    private func setupSegmentedControlStyle() {
        segmentedControl.selectedSegmentTintColor = .white
        segmentedControl.setTitleTextAttributes([.foregroundColor: brandColor, .font: UIFont.systemFont(ofSize: 14, weight: .semibold)], for: .selected)
        segmentedControl.setTitleTextAttributes([.foregroundColor: UIColor.gray, .font: UIFont.systemFont(ofSize: 14, weight: .regular)], for: .normal)
        segmentedControl.backgroundColor = .white
        segmentedControl.layer.cornerRadius = 10
        segmentedControl.layer.borderWidth = 1
        segmentedControl.layer.borderColor = UIColor.systemGray5.cgColor
    }
    
    @objc private func segmentChanged() {
        updateListForCurrentSegment()
    }
    
    private func updateListForCurrentSegment() {
        let selectedStatus: BookingStatus
        switch segmentedControl.selectedSegmentIndex {
        case 0: selectedStatus = .upcoming
        case 1: selectedStatus = .completed
        case 2: selectedStatus = .canceled
        default: selectedStatus = .upcoming
        }
        
        if selectedStatus == .canceled {
            filteredBookings = allBookings.filter { $0.status == .canceled || $0.status == .rejected }
        } else {
            filteredBookings = allBookings.filter { $0.status == selectedStatus }
        }
        tableView.reloadData()
    }
    
    // MARK: - TableView Methods
    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredBookings.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookingProviderCell", for: indexPath) as! BookingProviderCell
        let booking = filteredBookings[indexPath.row]
        cell.configure(with: booking, brandColor: brandColor)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let booking = filteredBookings[indexPath.row]
        
        if booking.status == .upcoming {
            let cancelAction = UIContextualAction(style: .destructive, title: "Cancel") { [weak self] _, _, handler in
                self?.updateBookingStatus(booking: booking, newStatus: "Canceled")
                handler(true)
            }
            cancelAction.backgroundColor = .systemOrange
            return UISwipeActionsConfiguration(actions: [cancelAction])
        }
        return nil
    }
    
    private func updateBookingStatus(booking: BookingModel, newStatus: String) {
        guard let id = booking.id else { return }
        Firestore.firestore().collection("bookings").document(id).updateData(["status": newStatus])
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowBookingDetails" {
            if let destinationVC = segue.destination as? BookingProviderDetailsTableViewController,
               let indexPath = sender as? IndexPath {
                let selectedBooking = filteredBookings[indexPath.row]
                destinationVC.bookingData = selectedBooking
                destinationVC.onStatusChanged = { [weak self] newStatus in
                    guard let self = self else { return }
                    if let index = self.allBookings.firstIndex(where: { $0.id == selectedBooking.id }) {
                        self.allBookings[index].status = newStatus
                    }
                    self.updateListForCurrentSegment()
                }
            }
        }
    }
}
