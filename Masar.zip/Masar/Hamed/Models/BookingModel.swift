import Foundation
import FirebaseFirestore

// حالات الحجز
enum BookingStatus: String, Codable {
    case upcoming = "Upcoming"
    case completed = "Completed"
    case canceled = "Canceled"
    case rejected = "Rejected"
}

/// مودل موحّد + بارسر مرن لقراءة اختلاف أسماء الحقول من Firestore
struct BookingModel: Codable {
    var id: String?
    let serviceName: String
    let providerName: String
    let seekerName: String
    let date: Date
    var status: BookingStatus

    /// السعر في قاعدة البيانات قد يأتي باسم totalPrice أو price
    let totalPrice: Double

    /// قد يأتي باسم notes أو instructions
    let notes: String?


    // ✅ Backward compatibility: بعض الشاشات تستخدم الاسم القديم instructions
    var instructions: String? { notes }
    /// قد تكون Optional حسب الداتا
    let email: String?
    let phoneNumber: String?

    let providerId: String?
    let seekerId: String?
    let serviceId: String?
    let descriptionText: String?

    // MARK: - Helpers
    var dateString: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    var priceString: String {
        return String(format: "%.3f BHD", totalPrice)
    }

    // MARK: - Firestore parsing (حل جذري لاختلاف الحقول)
    init?(id: String, data: [String: Any]) {
        // Required (مع fallback بسيط)
        guard let serviceName = data["serviceName"] as? String ?? data["service_title"] as? String,
              let seekerName = data["seekerName"] as? String ?? data["customerName"] as? String,
              let providerName = data["providerName"] as? String ?? data["provider_name"] as? String
        else { return nil }

        // Date
        if let ts = data["date"] as? Timestamp {
            self.date = ts.dateValue()
        } else if let ts = data["createdAt"] as? Timestamp {
            self.date = ts.dateValue()
        } else {
            return nil
        }

        // Status
        let statusString = (data["status"] as? String) ?? BookingStatus.upcoming.rawValue
        self.status = BookingStatus(rawValue: statusString) ?? .upcoming

        // Price (totalPrice OR price)
        let priceAny = data["totalPrice"] ?? data["price"] ?? 0
        if let d = priceAny as? Double {
            self.totalPrice = d
        } else if let i = priceAny as? Int {
            self.totalPrice = Double(i)
        } else if let s = priceAny as? String, let d = Double(s) {
            self.totalPrice = d
        } else {
            self.totalPrice = 0
        }

        // Notes (notes OR instructions)
        self.notes = data["notes"] as? String ?? data["instructions"] as? String

        // Optional fields
        self.email = data["email"] as? String
        self.phoneNumber = data["phoneNumber"] as? String ?? data["phone"] as? String

        self.providerId = data["providerId"] as? String
        self.seekerId = data["seekerId"] as? String
        self.serviceId = data["serviceId"] as? String
        self.descriptionText = data["descriptionText"] as? String ?? data["description"] as? String

        self.id = id
        self.serviceName = serviceName
        self.providerName = providerName
        self.seekerName = seekerName
    }
}
