//
//  FirebaseManager.swift
//  Masar
//
//  Created by BP-36-201-10 on 15/12/2025.
//

import Foundation

final class FirebaseManager {
    static let shared = FirebaseManager()
    private init() {}
}

